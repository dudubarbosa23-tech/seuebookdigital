
const ebooks = [
  {id:1, titulo:"Estrelas e Desejos", descricao:"Uma jornada única através da ficção e mistério.", preco:20, imagem:"img/estrela.jpg", link:"#"},
  {id:2, titulo:"Magia: Vertentes, História e Caminhos", descricao:"Exploração das vertentes e história da magia.", preco:50, imagem:"img/magia.jpg", link:"#"}  
];

const magia = [
  {id:101, titulo:"Mapa Astral", descricao:"Promoção por tempo indeterminado.", preco:30},
  {id:102, titulo:"Poções", descricao:"Vitalidade, Disposição, Sensibilidade Energética, Limpeza", preco:50},
  {id:103, titulo:"Feitiços", descricao:"Abertura de Caminhos, Oportunidades Profissionais, Insônia, Quebra de Amarrações", preco:80},
  {id:104, titulo:"Banimento", descricao:"Serviço especializado.", preco:100}
];

function renderItems(){
  const ebooksList=document.getElementById('ebooks-list');
  ebooksList.innerHTML='';
  ebooks.forEach(item=>{
    ebooksList.innerHTML+=`
      <div class="card">
        <img src="${item.imagem}" alt="${item.titulo}">
        <h3>${item.titulo}</h3>
        <p>${item.descricao}</p>
        <p class="price">R$${item.preco}</p>
        <button class="btn">Adicionar ao Carrinho</button>
        <button class="btn">Lista de Desejos</button>
        <a class="btn" href="${item.link}" target="_blank">Ver Amostra</a>
      </div>
    `;
  });

  const magiaList=document.getElementById('magia-list');
  magiaList.innerHTML='';
  magia.forEach(item=>{
    magiaList.innerHTML+=`
      <div class="card">
        <h3>${item.titulo}</h3>
        <p>${item.descricao}</p>
        <p class="price">R$${item.preco}</p>
        <button class="btn">Adicionar ao Carrinho</button>
        <button class="btn">Lista de Desejos</button>
      </div>
    `;
  });
}

renderItems();
