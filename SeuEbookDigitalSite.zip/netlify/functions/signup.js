
const { Client } = require('pg');
const bcrypt = require('bcryptjs');

exports.handler = async (event) => {
  const body = JSON.parse(event.body);
  const { nome, email, senha } = body;

  if (!nome || !email || !senha) {
    return { statusCode: 400, body: JSON.stringify({ error: "Preencha todos os campos" }) };
  }

  const client = new Client({
    connectionString: 'postgresql://neondb_owner:npg_qBKAng95fyGO@ep-small-waterfall-ae4kftgo-pooler.c-2.us-east-2.aws.neon.tech/neondb?sslmode=require&channel_binding=require',
    ssl: { rejectUnauthorized: false }
  });

  try {
    await client.connect();
    const hash = await bcrypt.hash(senha, 10);
    await client.query(
      'INSERT INTO usuarios (nome, email, senha_hash) VALUES ($1, $2, $3)',
      [nome, email, hash]
    );
    await client.end();
    return { statusCode: 200, body: JSON.stringify({ message: "Conta criada com sucesso" }) };
  } catch (err) {
    return { statusCode: 500, body: JSON.stringify({ error: err.message }) };
  }
};
